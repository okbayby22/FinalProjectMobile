#CPP101x_Assignment_02_HuyTNMFX01456

Name: Tran Ngoc Man Huy

Student ID: FX01456

I use Visual Studio 2019 to build this Assignment.

#Struture:

checkSpeed() : Is function to check speed switch gear to N,P

MenuGear(): Is function to show menu to switch gear

MenuGearRD(): Is function to show menu to set speed

switchGear(): Is function to switch between P,N,R,D mode and turn of the car

setSpeed(): Is function to set current speed of the car

switchGearRD(): Is function to increase or decrease speed of the car when the car in R or D mode

swap() : Swap two elements in array

bubbleSort() : Sort array with bubble sort

selectionSort() : Sort array with selection sort

printArray() : Use to print array in line

speedRanges() : Use to set 3 speed ranges

checkSpeedRanges(): Check Duplicate Speed Range

arrayEqual() : Check 2 arrays are equal or not

startSort() : Start sorting all arrays

compareSort() : Compare complexity between 2 sort (compare how many steps of each sort type)

main() : Is Main function of program
 


