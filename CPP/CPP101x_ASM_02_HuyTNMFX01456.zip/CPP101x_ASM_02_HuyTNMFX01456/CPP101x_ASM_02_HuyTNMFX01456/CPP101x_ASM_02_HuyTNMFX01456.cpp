// CPP101x_ASM_02_HuyTNMFX01456.cpp : This file contains the 'main' function. Program execution begins and ends there.
//Name: Tran Ngoc Man Huy
//Code: FX01456
//Subject: CPP101x
//Assignment: 2
#include<iostream>
#include<cstdlib>
#include<sstream>
#include<string>
#include<regex>

#define P 1				// gear of car
#define R 2				// gear of car
#define N 3				// gear of car
#define D 4				// gear of car
#define POWER_OFF 5		// turn ofF the engine
#define TANG_TOC 6		// increase speed
#define GIAM_TOC 7		// decrease speed
#define PHANH 8			// brake
#define MAIN_MENU 9		// back to main menu
using namespace std;

string pre_installed[8] = { "8","2","4","3","1","5","7","6" };
string code[8] = {};
int pre_size = sizeof(pre_installed) / sizeof(pre_installed[0]);
int code_size = sizeof(code) / sizeof(code[0]);
int gear, drivespeed = 0, respeed = 0, speed = 0;//Gear that drive choose
string speedLV[3];
int selection_step = 0, bubble_step = 0;
string bf_sort[8];
string bf_gear = "P";

/// <summary>
/// Method to check speed when switch gear to N,P
/// </summary>
/// <param name="gear">Gear that driver choose</param>
/// <param name="speed">Current speed of car</param>





void checkSpeed(string gear, int& speed) {
	if ((gear.compare("P") == 0 || gear.compare("N") == 0) && speed > 0) {
		cout << "HAY CHAC CHAN VAN TOC LA 0 KM/H" << endl << endl;
	}
	else {
		cout << "DA VE SO " << gear << endl << "CHU Y SU DUNG TAY PHANH DE DAM BAO AN TOAN" << endl << endl;
	}
}

/// <summary>
/// Method to show menu to switch gear
/// </summary>
void MenuGear() {
	cout << "1. P" << endl;
	cout << "2. R" << endl;
	cout << "3. N" << endl;
	cout << "4. D" << endl;
	cout << "5. POWER OFF" << endl;
}

/// <summary>
/// Method to show menu to set speed
/// </summary>
void MenuGearRD() {
	cout << "1.TANG TOC" << endl;
	cout << "2.GIAM TOC" << endl;
	cout << "3.PHANH" << endl;
	cout << "4.TRO VE MENU" << endl;
}


/// <summary>
/// Method to switch between P,N,R,D mode and turn of the car
/// </summary>
/// <returns>Gear that driver chooses</returns>
int switchGear() {
	string choose = "1"; //set default gear
	int gear; //return value
	cout << "3 MUC VAN TOC HIEN TAI LA: " << endl;
	for (int i = 0; i < 3; i++)
	{
		cout << speedLV[i] << " KM/H" << endl;

	}
	cout << endl;
	cout << "XIN MOI LUA CHON: " << endl;
	MenuGear();
	cin >> choose;
	do {
		if (!regex_match(choose, regex("[1-5]"))) {
			system("cls");
			cout << "XIN MOI LUA CHON LAI " << endl;
			MenuGear();
			cin >> choose;
			gear = 6;
		}
		else {
			gear = stoi(choose);
		}

	} while (gear > 5 || gear < 1);

	return gear;
}

/// <summary>
/// Set current speed for car
/// </summary>
/// <param name="respeed">Reverse speed</param>
/// <param name="drivespeed">Drive speed</param>
/// <param name="speed">Current speed of car</param>
void setSpeed(int& respeed, int& drivespeed, int& speed) {
	if (respeed == 0 && drivespeed == 0) {
		speed = 0;
	}
	else {
		speed = (respeed > drivespeed) ? respeed : drivespeed;
	}
}

/// <summary>
/// Method 
/// </summary>
/// <param name="speed">Current Drive(or Reverse) speed of the car</param>
/// <param name="typeDrive">Current type of car (R,D)</param>

void switchGearRD(int& speed, string typeDrive, string bf_gear) {
	//when start to drive or reverse, speed will will be set to 7
	if ((speed == 0 && bf_gear == "P") || (speed == 0 && bf_gear == "N")) {
		speed = 7;
	}
	int distance = 0;

	string choose = "1";		// set default gear that driver selected
	int gear = 1;					// variable use to choose menu
	do {
		do {
			system("cls");				// clear terminal screen
			if (typeDrive.compare("R") == 0) {
				cout << "DA VAO REVERSE MODE" << endl << endl;
			}
			else if (typeDrive.compare("D") == 0) {
				cout << "DA VAO DRIVE MODE" << endl << endl;
			}
			cout << "---- TOC DO HIEN TAI: " << speed << " KM/H" << endl << endl; //Print current speed to screen

			/*
			Check speed to warning driver about safety distance
			*/
			if (speed < stoi(speedLV[0])) {
				distance = 20;
			}
			else if (speed >= stoi(speedLV[0]) && speed < stoi(speedLV[1])) {
				distance = 55;
			}
			else if (speed >= stoi(speedLV[1]) && speed < stoi(speedLV[2])) {
				distance = 70;
			}
			else {
				distance = 100;
			}


			cout << "BAN CHU Y GIU KHOANG CACH TOI THIEU LA " << distance << "M" << endl;

			/*
				If speed is over 60 km / h in Drive gear (or over 20km/ h in Reverse gear)
				give warning to driver
			*/
			if ((typeDrive.compare("R") == 0 && speed >= 20)
				|| (typeDrive.compare("D") == 0 && speed >= 60)) {
				cout << "TOC DO NGUY HIEM, BAN NEN GIAM TOC DO" << endl;
				cout << endl;
			}
			cout << "MOI LUA CHON" << endl;
			MenuGearRD(); //Call method to show menu
			cout << ">>>>>>>";
			cin >> choose;
			//Check selection of driver 
			if (!regex_match(choose, regex("[1-4]"))) {  //If driver choose out of range [1-4], re-enter
				gear = 5;
			}
			else {

				gear = stoi(choose);
			}
			//check selected value from 1 to 4
		} while (!regex_match(choose, regex("[1-4]")));

		/*
			Choose TANG_TOC to increase car's speed
			Choose GIAM_TOC to decrease car's speed
			Choose PHANH to stop the car (set car's speed to 0)
		*/
		switch (gear + 5) { //plus 5 to suitable for defination
		case TANG_TOC:
			speed += 5;
			break;
		case GIAM_TOC:
			//speed can be negative number
			if (speed < 5) {
				speed = 0;
			}
			else {
				speed -= 5;
			}
			break;
		case PHANH:
			speed = 0;
			break;
		case MAIN_MENU: //Check to back to main menu
			break;
		}
	} while (gear >= 1 && gear < 4);
	system("cls"); // clear terminal screen
}

/// <summary>
/// Swap two element in array
/// </summary>
/// <param name="xp"></param>
/// <param name="yp"></param>

void swap(string* num1, string* num2, int* step)
{
	string temp = *num1;
	*num1 = *num2;
	*num2 = temp;
	*step += 1;
}

/// <summary>
/// Method use to sort array with bubble sort
/// </summary>
/// <param name="array"></param>
/// <param name="n"></param>

void bubbleSort(string array[8], int n) {
	int i, j;
	bubble_step = 0;
	for (i = 0; i < n - 1; i++) {
		// Last i elements are already in place
		for (j = 0; j < n - i - 1; j++) {
			if (stoi(array[j]) > stoi(array[j + 1])) {
				swap(&array[j], &array[j + 1], &bubble_step);
			}

		}

	}

}

/// <summary>
/// Method use to sort array with selection sort
/// </summary>
/// <param name="array">array need to be sorted</param>
/// <param name="n">size of array</param>
void selectionSort(string array[8], int n) {
	selection_step = 0;
	for (int i = 0; i < n - 1; i++)
	{
		int min_idx = i;
		for (int j = i + 1; j < n; j++)
			if (stoi(array[j]) < stoi(array[min_idx])) {
				min_idx = j;
			}
		swap(&array[min_idx], &array[i], &selection_step);

	}
}

/// <summary>
/// Method use to print array after sort
/// </summary>
/// <param name="array">sorted array</param>
/// <param name="n">size of array</param>

void printArray(string array[8], int n) {
	int i;
	for (i = 0; i < n; i++) {
		cout << array[i] << " ";
	}
	printf("\n");
}


/// <summary>
/// Set speed ranges for warning
/// </summary>
/// <param name="speedLV">String of speed</param>
void speedRanges(string speedLV[]) {
	cout << "CAI DAT VAN TOC CANH BAO KHOANG CACH AN TOAN VOI 3 MUC VAN TOC" << endl;
	for (int i = 0; i < 3; i++) {
		int j = i + 1;
		do {
			if (!regex_match(speedLV[i], regex("([\[0-9]*)"))) {
				cout << "SO DA NHAP KHONG HOP LE " << endl << "VUI LONG NHAP LAI" << endl;
			}
			cout << "VAN TOC MUC " << j << " : ";
			cin >> speedLV[i];
		} while (!regex_match(speedLV[i], regex("([\[0-9]*)")));
	}
	bubbleSort(speedLV, 3);
	system("cls");
}

/// <summary>
/// Check Duplicate Speed Ranges
/// </summary>
/// <param name="speedLV"></param>
/// <returns></returns>

bool checkSpeedRanges(string speedLV[]) {
	if (speedLV[0] == speedLV[1] || speedLV[0] == speedLV[2] || speedLV[1] == speedLV[2]) {
		return false;
	}
	else {
		return true;
	}

}


/// <summary>
/// Check 2 arrays are equal or not
/// </summary>
/// <param name="code"></param>
/// <param name="pre_installed"></param>
/// <returns></returns>
bool arrayEqual(string code[], string pre_installed[]) {
	for (int i = 0; i < 8; i++) {
		if (code[i] != pre_installed[i]) {
			return false;
		}
	}
	return true;
}


/// <summary>
/// Start sorting 2 arrays
/// </summary>

void startSort() {
	system("cls");
	cout << "MANG NHAP VAO TRUOC KHI SAP XEP: ";
	printArray(pre_installed, 8);
	cout << "---> MANG NHAP VAO SAU KHI SAP XEP: ";
	bubbleSort(pre_installed, 8);
	printArray(pre_installed, 8);
	cout << "MA SO CA NHAN TRUOC KHI SAP XEP: ";
	printArray(code, 8);
	cout << "---> MA SO CA NHAN SAU KHI SAP XEP: ";
	selectionSort(code, 8);
	printArray(code, 8);
	if (arrayEqual(code, pre_installed) == 0) {
		cout << endl << "MA KHONG HOP LE" << endl;
		exit(1); //exit program
	}
	else {
		cout << endl;

	}
}

/// <summary>
/// Compare complexity between 2 sort
/// </summary>

void compareSort() {
	bubbleSort(bf_sort, 8);
	cout << endl << "SO BUOC CUA BUBBLE SORT: " << bubble_step << endl;
	cout << endl << "SO BUOC CUA SELECTION SORT: " << selection_step << endl;
}

int main() {
	//Check enter code to start the car
	cout << "NHAP MA SO CA NHAN, MANG 08 SO " << endl;
	for (int i = 0; i < 8; i++) {
		int j = i + 1;
		do { //Check available input
			if (!regex_match(code[i], regex("([\[0-9]*)"))) {
				cout << "SO DA NHAP KHONG HOP LE " << endl << "VUI LONG NHAP LAI" << endl;
			}
			cout << "SO THU " << j << ": ";
			cin >> code[i];
		} while (!regex_match(code[i], regex("([\[0-9]*)")));
	}

	/*
	Create an array to compare two sort on 1 array.
	*/

	for (int i = 0; i < 8; i++) {
		bf_sort[i] = code[i];
	}
	startSort(); // Start sorting
	compareSort(); //Compare between two sort
	system("pause"); //Press any key two continue
	system("cls"); //Clear terminal's screen
	speedRanges(speedLV); //Create speed ranges
	while (!checkSpeedRanges(speedLV)) { //Check duplicate speed range
		system("cls");
		cout << "CAC MUC AN TOAN KHONG DUOC TRUNG NHAU " << endl;
		cout << "VUI LONG NHAP LAI" << endl;
		speedRanges(speedLV);
	}

	do {
		//clear terminal screen
		gear = switchGear(); //Call method to get gear that driver chooses
		switch (gear)
		{
		case P:
			system("cls");
			//Set and check speed that if car is still moving , give warning to driver to stop the car before switch to P mode
			setSpeed(respeed, drivespeed, speed);
			checkSpeed("P", speed);
			bf_gear = "P";
			break;
		case R:
			system("cls");
			if (drivespeed != 0) { //Check to make sure that car is stopping driving before switch to R mode
				cout << "HAY CHAC CHAN VAN TOC XE LA 0 KM/H TRUOC KHI LUI XE" << endl << endl;
			}
			else { //Start to drive in R mode
				switchGearRD(respeed, "R", bf_gear);
				bf_gear = "R";
			}
			break;
		case N:
			system("cls");
			//Set and check speed that if car is still moving , give warning to driver to stop the car before switch to N mode
			setSpeed(respeed, drivespeed, speed);
			checkSpeed("N", speed);
			bf_gear = "N";
			break;
		case D:
			system("cls");
			if (respeed != 0) { //Check to make sure that car is stopping reversing before switch to D mode
				cout << "HAY CHAC CHAN VAN TOC XE LA 0 KM/H TRUOC KHI CHUYEN TU LUI XE SANG CHAY XE" << endl << endl;
			}
			else { //Start to drive in D mode
				switchGearRD(drivespeed, "D", bf_gear);
				bf_gear = "D";
			}
			break;
		case POWER_OFF: //Turn of the car
			system("cls");
			cout << "CHAO TAM BIET"<< endl << "HEN GAP LAI" << endl;
			break;
		}
	} while (gear < 5 && gear >= 1);
	return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
